﻿INSTRUCCIONES DE INSTALACIÓN

1) Descargue y abra el archivo 'app-release.zip' y extraiga 'app-release.apk'.
2) En el teléfono, abra 'Files' o 'Downloads' y toque 'app-release.apk'.
3) Si Android bloquea la instalación:
   - Android 8+: Ajustes → Apps y notificaciones → Acceso especial → Instalar apps desconocidas → seleccione la app que usa (Files/Chrome) → activar 'Permitir desde esta fuente'.
   - Android 7 o menor: Ajustes → Seguridad → activar 'Orígenes desconocidos'.
4) Acepte los permisos y pulse Instalar.
5) Si la app no se conecta al backend: la app está configurada para conectarse a mi servidor local.
Esto para cargar los productos desde nuestra base de datos local ORACLE